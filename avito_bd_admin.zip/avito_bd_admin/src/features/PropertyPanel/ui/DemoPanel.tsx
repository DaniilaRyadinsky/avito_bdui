import * as React from "react";

import { PropertyPanel, type PropertyPanelValue } from "./PropertyPanel";


export const DemoPanel: React.FC = () => {
    const [state, setState] = React.useState<PropertyPanelValue>({
        modifier: {
            size: { width: "wrap_content", height: "wrap_content" },
            weight: 0,
            fillMaxWidth: false,
            fillMaxHeight: false,
            padding: { start: 8, end: 8, top: 8, bottom: 8 },
            align: "start",
            clip: { cornerRadius: 8 },
            background: "#ffffff",
            border: { width: 1, color: "#e5e7eb" },
            clickable: false,
            alpha: 1,
            shadow: { elevation: 0, color: 0 }
        },
        textStyle: {
            fontSize: 16,
            fontWeight: "normal",
            fontStyle: "normal",
            color: "#111827",
            lineHeight: 20,
            letterSpacing: 0,
            textDecoration: "none",
            textAlign: "start",
            maxLines: 0,
            overflow: "visible"
        },
        buttonStyle: {
            background: "#111827",
            textColor: "#ffffff",
            fontSize: 16,
            fontWeight: "bold",
            fontStyle: "normal",
            shape: { cornerRadius: 12, topStart: 12, topEnd: 12 },
            border: { width: 1, color: "#111827" }
        },
        contentScale: "None"
    });


    return (
        <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-6">
            <PropertyPanel value={state} onChange={setState} className="self-start" />


            <div className="rounded-2xl border p-6 bg-background">
                <div className="text-sm font-semibold mb-4 text-muted-foreground">Live Preview</div>
                <button
                    className="px-4 py-2 rounded-2xl shadow-sm border"
                    style={{
                        width: typeof state.modifier.size.width === "number" ? state.modifier.size.width : undefined,
                        height: typeof state.modifier.size.height === "number" ? state.modifier.size.height : undefined,
                        background: state.buttonStyle?.background ?? state.modifier.background,
                        color: state.buttonStyle?.textColor ?? state.textStyle?.color,
                        opacity: state.modifier.alpha,
                        borderWidth: state.modifier.border.width,
                        borderColor: state.modifier.border.color,
                        borderStyle: "solid",
                        borderRadius: state.modifier.clip.cornerRadius,
                        padding: `${state.modifier.padding.top}px ${state.modifier.padding.end}px ${state.modifier.padding.bottom}px ${state.modifier.padding.start}px`,
                    }}
                >
                    <span
                        style={{
                            fontSize: state.textStyle?.fontSize ?? state.buttonStyle?.fontSize,
                            fontWeight: state.textStyle?.fontWeight ?? state.buttonStyle?.fontWeight,
                            fontStyle: state.textStyle?.fontStyle ?? state.buttonStyle?.fontStyle,
                            textDecoration: state.textStyle?.textDecoration === "underline" ? "underline" : state.textStyle?.textDecoration === "lineThrough" ? "line-through" : "none",
                            letterSpacing: state.textStyle?.letterSpacing,
                            lineHeight: state.textStyle?.lineHeight ? `${state.textStyle?.lineHeight}px` : undefined,
                        }}
                    >
                        Button / Text
                    </span>
                </button>
            </div>
        </div>
    );
};