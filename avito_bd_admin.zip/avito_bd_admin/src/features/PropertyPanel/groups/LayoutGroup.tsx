import * as React from "react";
import { Section } from "./Section";
import { Row, NumberInput, SelectBox } from "./FieldPrimitives";
import type { Modifier, Size } from "../model/types";


const pctOrBoolOptions = [
    { label: "Off", value: "false" },
    { label: "100%", value: "true" },
    { label: "25%", value: "0.25" },
    { label: "33%", value: "0.33" },
    { label: "50%", value: "0.5" },
    { label: "66%", value: "0.66" },
    { label: "75%", value: "0.75" },
    { label: "90%", value: "0.9" },
];


export const LayoutGroup: React.FC<{
    value: Modifier; onChange: (next: Partial<Modifier>) => void;
}> = ({ value, onChange }) => {
    const setSize = (patch: Partial<Size>) => onChange({ size: { ...value.size, ...patch } as Size });
    return (
        <Section title="Layout">
            <Row label="Width">
                <div className="grid grid-cols-2 gap-2">
                    <SelectBox
                        value={typeof value.size.width === "number" ? "px" : String(value.size.width)}
                        onChange={(v) => { if (v === "wrap_content") setSize({ width: "wrap_content" }); }}
                        options={[{ label: "wrap_content", value: "wrap_content" }, { label: "px", value: "px" }]}
                    />
                    {typeof value.size.width === "number" ? (
                        <NumberInput value={value.size.width} onChange={(n) => setSize({ width: n })} />
                    ) : (
                        <button className="h-9 rounded-md border px-3 text-sm" onClick={() => setSize({ width: 100 })}>Set px</button>
                    )}
                </div>
            </Row>


            <Row label="Height">
                <div className="grid grid-cols-2 gap-2">
                    <SelectBox
                        value={typeof value.size.height === "number" ? "px" : String(value.size.height)}
                        onChange={(v) => { if (v === "wrap_content") setSize({ height: "wrap_content" }); }}
                        options={[{ label: "wrap_content", value: "wrap_content" }, { label: "px", value: "px" }]}
                    />
                    {typeof value.size.height === "number" ? (
                        <NumberInput value={value.size.height} onChange={(n) => setSize({ height: n })} />
                    ) : (
                        <button className="h-9 rounded-md border px-3 text-sm" onClick={() => setSize({ height: 100 })}>Set px</button>
                    )}
                </div>
            </Row>


            <Row label="Weight"><NumberInput value={value.weight} onChange={(n) => onChange({ weight: n })} /></Row>


            <Row label="Fill max width">
                <SelectBox value={String(value.fillMaxWidth)} onChange={(v) => onChange({ fillMaxWidth: v === "true" ? true : v === "false" ? false : Number(v) })} options={pctOrBoolOptions} />
            </Row>
            <Row label="Fill max height">
                <SelectBox value={String(value.fillMaxHeight)} onChange={(v) => onChange({ fillMaxHeight: v === "true" ? true : v === "false" ? false : Number(v) })} options={pctOrBoolOptions} />
            </Row>


            <Row label="Align">
                <SelectBox value={value.align} onChange={(v) => onChange({ align: v as any })}
                    options={["start", "center", "end", "top", "bottom"].map(x => ({ label: x, value: x }))}
                />
            </Row>
        </Section>
    );
};