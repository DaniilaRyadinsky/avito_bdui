import * as React from "react";
import { Section } from "./Section";
import { Row, NumberInput, SelectBox, ColorInput } from "./FieldPrimitives";
import type { TextStyle } from "../model/types";


export const TextStyleGroup: React.FC<{
value: TextStyle; onChange: (next: Partial<TextStyle>)=>void
}> = ({ value, onChange }) => (
<Section title="Text">
<Row label="Font size"><NumberInput value={value.fontSize} onChange={(n)=>onChange({ fontSize: n })} /></Row>
<Row label="Font weight">
<SelectBox value={value.fontWeight} onChange={(v)=>onChange({ fontWeight: v as any })} options={["normal","bold","medium"].map(x=>({label:x,value:x}))} />
</Row>
<Row label="Font style">
<SelectBox value={value.fontStyle} onChange={(v)=>onChange({ fontStyle: v as any })} options={["normal","italic"].map(x=>({label:x,value:x}))} />
</Row>
<Row label="Color"><ColorInput value={value.color} onChange={(c)=>onChange({ color: c })} /></Row>
<Row label="Line height"><NumberInput value={value.lineHeight} onChange={(n)=>onChange({ lineHeight: n })} /></Row>
<Row label="Letter spacing"><NumberInput value={value.letterSpacing} onChange={(n)=>onChange({ letterSpacing: n })} /></Row>
<Row label="Decoration">
<SelectBox value={value.textDecoration} onChange={(v)=>onChange({ textDecoration: v as any })} options={["none","underline","lineThrough"].map(x=>({label:x,value:x}))} />
</Row>
<Row label="Align">
<SelectBox value={value.textAlign} onChange={(v)=>onChange({ textAlign: v as any })} options={["start","end","center","justify"].map(x=>({label:x,value:x}))} />
</Row>
<Row label="Max lines"><NumberInput value={value.maxLines} onChange={(n)=>onChange({ maxLines: n })} /></Row>
<Row label="Overflow">
<SelectBox value={value.overflow} onChange={(v)=>onChange({ overflow: v as any })} options={["clip","ellipsis","visible"].map(x=>({label:x,value:x}))} />
</Row>
</Section>
);