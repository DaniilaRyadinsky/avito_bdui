import * as React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";


export const Section: React.FC<{ title: string; children: React.ReactNode }>=({ title, children }) => (
<Card className="border-muted/60">
<CardHeader className="py-3">
<CardTitle className="text-sm font-semibold text-muted-foreground">{title}</CardTitle>
</CardHeader>
<CardContent className="grid gap-3">{children}</CardContent>
</Card>
);