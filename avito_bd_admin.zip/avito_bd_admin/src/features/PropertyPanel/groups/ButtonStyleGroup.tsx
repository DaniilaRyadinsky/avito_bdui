import * as React from "react";
import { Section } from "./Section";
import { Row, NumberInput, SelectBox, ColorInput } from "./FieldPrimitives";
import type { ButtonStyle, Shape, Border } from "../model/types";


const BorderEditor: React.FC<{ value: Border; onChange: (next: Partial<Border>)=>void }>=({ value, onChange }) => (
<div className="grid grid-cols-2 gap-3">
<Row label="Width"><NumberInput value={value.width} onChange={(n)=>onChange({ width: n })} /></Row>
<Row label="Color"><ColorInput value={value.color} onChange={(c)=>onChange({ color: c })} /></Row>
</div>
);


const ShapeEditor: React.FC<{ value: Shape; onChange: (next: Partial<Shape>)=>void }>=({ value, onChange }) => (
<div className="grid grid-cols-2 gap-3">
<Row label="Corner radius"><NumberInput value={value.cornerRadius} onChange={(n)=>onChange({ cornerRadius: n })} /></Row>
<Row label="Top start"><NumberInput value={value.topStart} onChange={(n)=>onChange({ topStart: n })} /></Row>
<Row label="Top end"><NumberInput value={value.topEnd} onChange={(n)=>onChange({ topEnd: n })} /></Row>
</div>
);


export const ButtonStyleGroup: React.FC<{
value: ButtonStyle; onChange: (next: Partial<ButtonStyle>)=>void
}> = ({ value, onChange }) => (
<Section title="Button Style">
<Row label="Background"><ColorInput value={value.background} onChange={(c)=>onChange({ background: c })} /></Row>
<Row label="Text color"><ColorInput value={value.textColor} onChange={(c)=>onChange({ textColor: c })} /></Row>
<Row label="Font size"><NumberInput value={value.fontSize} onChange={(n)=>onChange({ fontSize: n })} /></Row>
<Row label="Font weight">
<SelectBox value={value.fontWeight} onChange={(v)=>onChange({ fontWeight: v as any })} options={["normal","bold","medium"].map(x=>({label:x,value:x}))} />
</Row>
<Row label="Font style">
<SelectBox value={value.fontStyle} onChange={(v)=>onChange({ fontStyle: v as any })} options={["normal","italic"].map(x=>({label:x,value:x}))} />
</Row>
<Section title="Shape"><ShapeEditor value={value.shape} onChange={(p)=>onChange({ shape: { ...value.shape, ...p } })} /></Section>
<Section title="Border"><BorderEditor value={value.border} onChange={(p)=>onChange({ border: { ...value.border, ...p } })} /></Section>
</Section>
);