import * as React from "react";
import { Section } from "./Section";
import { Row, NumberInput, BoolSwitch } from "./FieldPrimitives";
import type { Padding } from "../model/types";


export const PaddingGroup: React.FC<{ value: Padding; onChange: (next: Padding)=>void }>=({ value, onChange }) => {
const [linkAll, setLinkAll] = React.useState<boolean>(value.all !== undefined);
const setAll = (n: number) => onChange({ start: n, end: n, top: n, bottom: n, all: n });


return (
<Section title="Padding">
<Row label="Link all">
<div className="flex items-center gap-3">
<BoolSwitch checked={linkAll} onChange={(v)=>{ setLinkAll(v); if(v) setAll(value.all ?? 0); else onChange({ ...value, all: undefined }); }} />
<span className="text-xs text-muted-foreground">Apply same value to all sides</span>
</div>
</Row>


{linkAll ? (
<Row label="All"><NumberInput value={value.all ?? 0} onChange={(n)=> setAll(n)} /></Row>
) : (
<div className="grid grid-cols-2 gap-3">
<Row label="Start"><NumberInput value={value.start} onChange={(n)=> onChange({ ...value, start: n })} /></Row>
<Row label="End"><NumberInput value={value.end} onChange={(n)=> onChange({ ...value, end: n })} /></Row>
<Row label="Top"><NumberInput value={value.top} onChange={(n)=> onChange({ ...value, top: n })} /></Row>
<Row label="Bottom"><NumberInput value={value.bottom} onChange={(n)=> onChange({ ...value, bottom: n })} /></Row>
</div>
)}
</Section>
);
};