import * as React from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";


export const Row: React.FC<{ label?: string; children: React.ReactNode }> = ({ label, children }) => (
    <div className="grid grid-cols-12 items-center gap-3">
        {label && <Label className="col-span-5 text-sm text-muted-foreground">{label}</Label>}
        <div className={label ? "col-span-7" : "col-span-12"}>{children}</div>
    </div>
);


export const NumberInput: React.FC<{
    value: number; onChange: (v: number) => void; min?: number; max?: number; step?: number; placeholder?: string;
}> = ({ value, onChange, min, max, step = 1, placeholder }) => (
    <Input type="number" value={Number.isFinite(value) ? value : 0} min={min} max={max} step={step} placeholder={placeholder}
        onChange={(e) => onChange(Number(e.target.value))} />
);


export const TextInput: React.FC<{ value: string; onChange: (v: string) => void; placeholder?: string }> = ({ value, onChange, placeholder }) => (
    <Input value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} />
);


export const SelectBox: React.FC<{
    value: string; onChange: (v: string) => void; options: { label: string; value: string }[];
}> = ({ value, onChange, options }) => (
    <Select value={value} onValueChange={onChange}>
        <SelectTrigger><SelectValue /></SelectTrigger>
        <SelectContent>
            {options.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
        </SelectContent>
    </Select>
);


export const BoolSwitch: React.FC<{ checked: boolean; onChange: (v: boolean) => void }> = ({ checked, onChange }) => (
    <Switch checked={checked} onCheckedChange={onChange} />
);


export const ColorInput: React.FC<{ value: string; onChange: (v: string) => void }> = ({ value, onChange }) => (
    <div className="flex items-center gap-3">
        <input type="color" className="h-9 w-9 rounded-md border" value={value} onChange={(e) => onChange(e.target.value)} />
        <Input value={value} onChange={(e) => onChange(e.target.value)} />
    </div>
);