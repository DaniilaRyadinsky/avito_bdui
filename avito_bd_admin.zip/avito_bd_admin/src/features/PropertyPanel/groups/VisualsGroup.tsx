import * as React from "react";
import { Section } from "./Section";
import { Row, NumberInput, ColorInput } from "./FieldPrimitives";
import type { Modifier, Shadow } from "../model/types";


const ShadowEditor: React.FC<{ value: Shadow; onChange: (next: Partial<Shadow>)=>void }>=({ value, onChange }) => (
<div className="grid grid-cols-2 gap-3">
<Row label="Elevation"><NumberInput value={value.elevation} onChange={(n)=>onChange({ elevation: n })} /></Row>
<Row label="Color (int)"><NumberInput value={value.color} onChange={(n)=>onChange({ color: n })} /></Row>
</div>
);


export const VisualsGroup: React.FC<{ value: Modifier; onChange: (next: Partial<Modifier>)=>void }>=({ value, onChange }) => (
<Section title="Visuals">
<Row label="Background"><ColorInput value={value.background} onChange={(c)=>onChange({ background: c })} /></Row>
<Section title="Border">
<div className="grid grid-cols-2 gap-3">
<Row label="Width"><NumberInput value={value.border.width} onChange={(n)=>onChange({ border: { ...value.border, width: n } })} /></Row>
<Row label="Color"><ColorInput value={value.border.color} onChange={(c)=>onChange({ border: { ...value.border, color: c } })} /></Row>
</div>
</Section>
<Row label="Clip radius"><NumberInput value={value.clip.cornerRadius} onChange={(n)=>onChange({ clip: { cornerRadius: n } })} /></Row>
<Section title="Shadow"><ShadowEditor value={value.shadow} onChange={(p)=>onChange({ shadow: { ...value.shadow, ...p } })} /></Section>
<Row label="Alpha"><NumberInput value={value.alpha} step={0.05} onChange={(n)=>onChange({ alpha: n })} /></Row>
</Section>
);