import * as React from "react";
import { Section } from "./Section";
import { Row, SelectBox, BoolSwitch } from "./FieldPrimitives";
import type { Modifier, ContentScale } from "../model/types";


export const AdvancedGroup: React.FC<{
modifier: Modifier;
onChange: (next: Partial<Modifier>)=>void;
contentScale?: ContentScale;
onContentScaleChange?: (v: ContentScale)=>void;
}> = ({ modifier, onChange, contentScale, onContentScaleChange }) => (
<Section title="Advanced">
<Row label="Clickable"><BoolSwitch checked={modifier.clickable} onChange={(v)=>onChange({ clickable: v })} /></Row>
{onContentScaleChange && (
<Row label="Content scale">
<SelectBox value={String(contentScale ?? "None")} onChange={(v)=> onContentScaleChange(v as ContentScale)}
options={["Fill","FillHeight","Crop","FillWidth","Inside","None","FillBounds"].map(x=>({label:x, value:x}))}
/>
</Row>
)}
</Section>
);