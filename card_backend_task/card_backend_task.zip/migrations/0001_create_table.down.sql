-- Удаление таблиц связей
DROP TABLE IF EXISTS cards;