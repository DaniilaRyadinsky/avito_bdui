package format

// import (
// 	"log"
// 	"productService/internal/views"
// 	"testing"
// )

// func TestStruct(t *testing.T) {
// 	p := views.Product{
// 		Id:        "test",
// 		Sizes:     "test",
// 		Materials: "test",
// 		Colors:    "test",
// 		Photos: []string{
// 			"test",
// 			"test",
// 		},
// 		Seems: []string{
// 			"test",
// 			"test",
// 		},
// 		Price: 1488,
// 	}

// 	log.Println(Struct(p))
// }
